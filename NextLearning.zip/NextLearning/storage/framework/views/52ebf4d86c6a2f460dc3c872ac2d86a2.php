<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">User Management</h5>
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create users')): ?>
            <a class="btn btn-success btn-sm me-2" href="<?php echo e(route('admin.users.create')); ?>">
                <span data-feather="user-plus"></span> Add User
            </a>
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.users.bulk-create')); ?>">
                <span data-feather="users"></span> Bulk Create
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tabs for filtering by role -->
    <div class="card-body">
        <ul class="nav nav-tabs mb-3">
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'students' ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.users.index', ['tab' => 'students'])); ?>">
                    <span data-feather="users"></span> Students
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'teachers' ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.users.index', ['tab' => 'teachers'])); ?>">
                    <span data-feather="user-check"></span> Teachers
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'admins' ? 'active' : ''); ?>"
                    href="<?php echo e(route('admin.users.index', ['tab' => 'admins'])); ?>">
                    <span data-feather="shield"></span> Admins
                </a>
            </li>
        </ul>

        <!-- Search & Filter -->
        <form method="GET" class="mb-4">
            <input type="hidden" name="tab" value="<?php echo e($tab); ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search by name or email..."
                        value="<?php echo e($search ?? ''); ?>">
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="1" <?php echo e(($status ?? '' )==='1' ? 'selected' : ''); ?>>Active</option>
                        <option value="0" <?php echo e(($status ?? '' )==='0' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">
                        <span data-feather="search"></span> Search
                    </button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            Name
                        </th>
                        <th>
                            Email
                        </th>
                        <th>
                            Roles
                        </th>
                        <th>
                            Status
                        </th>
                        <th>
                            Register At
                        </th>
                        <th>
                            Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-entry-id="<?php echo e($user->id); ?>">
                        <td>
                            <?php echo e($user->id_number ?? ''); ?>

                        </td>
                        <td>
                            <?php echo e($user->name ?? ''); ?>

                        </td>
                        <td>
                            <?php echo e($user->email ?? ''); ?>

                        </td>
                        <td>
                            <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-info"><?php echo e($item); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if($user->status): ?>
                            <span class="badge bg-success">Active</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Blocked</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($user->created_at->format('Y-m-d') ?? ''); ?>

                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit users')): ?>
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                    class="btn btn-sm btn-outline-warning" title="Edit">
                                    <span data-feather="edit-2"></span>
                                </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete users')): ?>
                                <?php if(auth()->user()->hasRole('Admin') && $user->id !== auth()->id()): ?>
                                <?php if($user->status): ?>
                                <form action="<?php echo e(route('admin.user.toggleStatus', ['id' => $user->id])); ?>" method="POST"
                                    style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="0">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Deactivate">
                                        <span data-feather="user-x"></span>
                                    </button>
                                </form>
                                <?php else: ?>
                                <form action="<?php echo e(route('admin.user.toggleStatus', ['id' => $user->id])); ?>" method="POST"
                                    style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="1">
                                    <button type="submit" class="btn btn-sm btn-outline-success" title="Activate">
                                        <span data-feather="user-check"></span>
                                    </button>
                                </form>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-center">
        <?php echo e($users->links('pagination::bootstrap-5')); ?>

    </div>
</div>

<!-- Quick Tips -->
<div class="alert alert-info mt-4">
    <strong><span data-feather="info"></span> Quick Tips - Action Icons:</strong>
    <ul class="mb-0 mt-2">
        <li><span data-feather="edit-2" style="width:16px;height:16px;"></span> <strong>Edit</strong> - Modify user
            details, role, or class enrollment</li>
        <li><span data-feather="user-x" style="width:16px;height:16px;"></span> <strong>Deactivate</strong> -
            Temporarily disable user account (shown for active users)</li>
        <li><span data-feather="user-check" style="width:16px;height:16px;"></span> <strong>Activate</strong> -
            Re-enable user account (shown for inactive users)</li>
        <li>Use the <strong>tabs</strong> (Students, Teachers, Admins) to filter users by role</li>
    </ul>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/users/index.blade.php ENDPATH**/ ?>