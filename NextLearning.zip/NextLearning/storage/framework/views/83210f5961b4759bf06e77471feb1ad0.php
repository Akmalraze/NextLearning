<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Report Management
    </div>

    <div class="card-body">
        
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageReport/index.blade.php ENDPATH**/ ?>