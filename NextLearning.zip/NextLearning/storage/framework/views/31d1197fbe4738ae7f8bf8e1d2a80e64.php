<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Manage Enrollments: <?php echo e($class->form_level); ?> <?php echo e($class->name ?? $class->class_name); ?></h5>
        <a href="<?php echo e(route('admin.classes.show', $class->id)); ?>" class="btn btn-secondary btn-sm">
            <span data-feather="arrow-left"></span> Back to Class
        </a>
    </div>
    <div class="card-body">
        <!-- Add Student Form -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h6 class="mb-0"><span data-feather="user-plus"></span> Add Student to Class</h6>
            </div>
            <div class="card-body">
                <?php if($availableStudents->count() > 0): ?>
                <form action="<?php echo e(route('admin.classes.enroll', $class->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-8">
                            <select name="student_id" class="form-select" required>
                                <option value="">Select a student...</option>
                                <?php $__currentLoopData = $availableStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>">
                                    <?php echo e($student->name); ?> (<?php echo e($student->email); ?>)
                                    <?php if($student->id_number): ?>
                                    - ID: <?php echo e($student->id_number); ?>

                                    <?php endif; ?>
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success w-100">
                                <span data-feather="plus-circle"></span> Enroll Student
                            </button>
                        </div>
                    </div>
                </form>
                <?php else: ?>
                <div class="alert alert-info mb-0">
                    <span data-feather="info"></span> All students are already enrolled in classes.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Enrolled Students List -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <h6 class="mb-0">
                    <span data-feather="users"></span>
                    Enrolled Students (<?php echo e($enrolledStudents->count()); ?>)
                </h6>
            </div>
            <div class="card-body">
                <?php if($enrolledStudents->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>ID Number</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->id); ?></td>
                                <td>
                                    <strong><?php echo e($student->name); ?></strong>
                                </td>
                                <td><?php echo e($student->email); ?></td>
                                <td>
                                    <?php if($student->id_number): ?>
                                    <span class="badge bg-secondary"><?php echo e($student->id_number); ?></span>
                                    <?php else: ?>
                                    <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-success">Active</span>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('admin.classes.unenroll', [$class->id, $student->id])); ?>"
                                        method="POST"
                                        onsubmit="return confirm('Remove <?php echo e($student->name); ?> from this class?');"
                                        style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                            title="Remove from class">
                                            <span data-feather="user-x"></span>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    <span data-feather="alert-triangle"></span> No students enrolled in this class yet.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Tips -->
        <div class="alert alert-info mt-4">
            <strong><span data-feather="info"></span> Quick Tips:</strong>
            <ul class="mb-0 mt-2">
                <li><span data-feather="plus-circle" style="width:16px;height:16px;"></span> <strong>Enroll:</strong>
                    Select a student from the dropdown and click "Enroll Student"</li>
                <li><span data-feather="user-x" style="width:16px;height:16px;"></span> <strong>Remove:</strong> Click
                    the remove button to unenroll a student from this class</li>
                <li><span data-feather="alert-circle" style="width:16px;height:16px;"></span> <strong>Note:</strong>
                    Only students without an active class enrollment are shown in the dropdown</li>
            </ul>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/classes/enrollments.blade.php ENDPATH**/ ?>