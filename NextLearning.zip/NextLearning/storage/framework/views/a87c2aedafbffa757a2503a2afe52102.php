<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">
                📚 <?php echo e($subject->name); ?> – Let’s Learn
            </h5>
        </div>

        <div class="card-body">

            <?php $__empty_1 = true; $__currentLoopData = $subject->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <div class="card mb-4 border">
                    <div class="card-body">

                        
                        <h5 class="fw-bold text-primary mb-2">
                             <?php echo e($module->modules_name); ?>

                        </h5>

                        <?php if($module->modules_description): ?>
                            <p class="text-muted mb-3">
                                <?php echo e($module->modules_description); ?>

                            </p>
                        <?php endif; ?>

                        
                        <h6 class="fw-semibold mb-2">📂 Learning Materials</h6>

                        <?php $__empty_2 = true; $__currentLoopData = $module->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <div class="card mb-2">
                                <div class="card-body py-2">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <p class="mb-1 fw-semibold">
                                                <?php echo e($material->materials_name); ?>

                                            </p>

                                            <?php if($material->materials_notes): ?>
                                                <p class="text-muted mb-0">
                                                    <?php echo e($material->materials_notes); ?>

                                                </p>
                                            <?php endif; ?>
                                        </div>

                                        <div>
                                            <a href="<?php echo e(asset('storage/' . $material->file_path)); ?>"
                                               class="btn btn-sm btn-outline-success"
                                               download>
                                                ⬇ Download
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <div class="alert alert-secondary mb-0">
                                No learning materials uploaded for this module.
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-secondary text-center">
                    No modules available under this subject.
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageModule/list.blade.php ENDPATH**/ ?>