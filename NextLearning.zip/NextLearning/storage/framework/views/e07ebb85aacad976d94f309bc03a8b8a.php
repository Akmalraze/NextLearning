<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">
                 Module: <?php echo e($module->modules_name); ?>

            </h5>
        </div>

        <div class="card-body">
            <p class="text-muted">
                <?php echo e($module->modules_description); ?>

            </p>

            <hr>

            
            <h6 class="mb-3 fw-bold">📂 Learning Materials</h6>

            <?php $__empty_1 = true; $__currentLoopData = $module->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-3 border">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="fw-semibold mb-1">
                                    <?php echo e($material->materials_name); ?>

                                </h6>

                                <?php if($material->materials_notes): ?>
                                    <p class="text-muted mb-2">
                                        <?php echo e($material->materials_notes); ?>

                                    </p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <a href="<?php echo e(asset('storage/' . $material->file_path)); ?>"
                                   class="btn btn-sm btn-outline-success"
                                   download>
                                    ⬇ Download
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-secondary text-center">
                    No learning materials have been uploaded for this module yet.
                </div>
            <?php endif; ?>

            
            <?php if(!auth()->user()->hasRole('Student')): ?>
                <div class="text-end mt-4">
                    <a href="<?php echo e(route('materials-create', $module->id)); ?>"
                       class="btn btn-primary">
                         Add New Material
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageModule/view.blade.php ENDPATH**/ ?>