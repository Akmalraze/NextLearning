<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <div class="card mb-3">
        <div class="card-body">
            <h4 class="mb-1">Teaching Progress Report</h4>
            <p class="text-muted mb-0">View assessment progress and student lists for your assigned classes.</p>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('teacher.report')); ?>" class="row g-2 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Academic Session</label>
                    <select name="session" class="form-select">
                        <option value="">All Sessions</option>
                        <?php $__currentLoopData = $allSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($session); ?>" <?php echo e($selectedSession == $session ? 'selected' : ''); ?>>
                                <?php echo e($session); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>

    
    <?php if(count($classReports) > 0): ?>
        <ul class="nav nav-tabs mb-3" role="tablist">
            <?php $__currentLoopData = $classReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <button class="nav-link <?php echo e($index === 0 ? 'active' : ''); ?>" data-bs-toggle="tab"
                        data-bs-target="#classTab<?php echo e($index); ?>" type="button" role="tab">
                        <?php echo e($class['class_name']); ?>

                    </button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="tab-content">
            <?php $__currentLoopData = $classReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($index === 0 ? 'show active' : ''); ?>" id="classTab<?php echo e($index); ?>">
                    
                    <div class="d-flex justify-content-end gap-2 mb-3">
                        
                        <form method="GET" action="<?php echo e(route('teacher.report.export')); ?>">
                            <input type="hidden" name="type" value="progress">
                            <input type="hidden" name="class_ids[]" value="<?php echo e($class['class_id']); ?>">
                            <input type="hidden" name="session" value="<?php echo e($selectedSession); ?>">
                            <button class="btn btn-outline-primary btn-sm">Export Progress CSV</button>
                        </form>
                        
                        <form method="GET" action="<?php echo e(route('teacher.report.export')); ?>">
                            <input type="hidden" name="type" value="students">
                            <input type="hidden" name="class_ids[]" value="<?php echo e($class['class_id']); ?>">
                            <input type="hidden" name="session" value="<?php echo e($selectedSession); ?>">
                            <button class="btn btn-outline-secondary btn-sm">Export Students CSV</button>
                        </form>
                    </div>

                    
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item">
                            <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#progress<?php echo e($index); ?>">
                                Progress
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#students<?php echo e($index); ?>">
                                Students
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content">
                        
                        <div class="tab-pane fade show active" id="progress<?php echo e($index); ?>">
                            <div class="table-responsive">
                                <table class="table table-bordered align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Subject</th>
                                            <th>Total Assessments</th>
                                            <th>Completed</th>
                                            <th>Progress</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $class['subjects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($subject['subject_name']); ?></td>
                                                <td><?php echo e($subject['total']); ?></td>
                                                <td><?php echo e($subject['completed']); ?></td>
                                                <td><span class="badge bg-info"><?php echo e($subject['progress']); ?>%</span></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr><td colspan="4" class="text-center text-muted">No subject data available.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        
                        <div class="tab-pane fade" id="students<?php echo e($index); ?>">
                            <div class="table-responsive">
                                <table class="table table-bordered align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Student ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $class['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($student->id); ?></td>
                                                <td><?php echo e($student->name); ?></td>
                                                <td><?php echo e($student->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr><td colspan="3" class="text-center text-muted">No students found.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">No classes assigned for the selected session.</div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageReport/teacherreport.blade.php ENDPATH**/ ?>