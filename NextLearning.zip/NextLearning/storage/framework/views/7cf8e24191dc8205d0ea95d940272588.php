<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Subject Management</h5>
        <a href="<?php echo e(route('admin.subjects.create')); ?>" class="btn btn-primary btn-sm">
            <span data-feather="plus"></span> Add Subject
        </a>
    </div>
    <div class="card-body">
        <!-- Search & Filter -->
        <form method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search by name or code..."
                        value="<?php echo e($search ?? ''); ?>">
                </div>
                <div class="col-md-4">
                    <select name="is_active" class="form-select">
                        <option value="">All Status</option>
                        <option value="1" <?php echo e(($isActive ?? '' )==='1' ? 'selected' : ''); ?>>Active</option>
                        <option value="0" <?php echo e(($isActive ?? '' )==='0' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">
                        <span data-feather="search"></span> Filter
                    </button>
                </div>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Subject Name</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($subject->name ?? $subject->subjects_name); ?></td>
                        <td><code><?php echo e($subject->code ?? $subject->subjects_code); ?></code></td>
                        <td><?php echo e(Str::limit($subject->description ?? '', 50)); ?></td>
                        <td>
                            <?php if($subject->is_active): ?>
                            <span class="badge bg-success">Active</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.subjects.edit', $subject->id)); ?>"
                                    class="btn btn-sm btn-outline-warning" title="Edit">
                                    <span data-feather="edit-2"></span>
                                </a>
                                <form action="<?php echo e(route('admin.subjects.destroy', $subject->id)); ?>" method="POST"
                                    style="display:inline;" onsubmit="return confirm('Delete this subject?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                        <span data-feather="trash-2"></span>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">No subjects found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3 d-flex justify-content-center"><?php echo e($subjects->links('pagination::bootstrap-5')); ?></div>
    </div>
</div>
<div class="alert alert-info mt-4">
    <strong><span data-feather="info"></span> Quick Tips - Action Icons:</strong>
    <ul class="mb-0 mt-2">
        <li><span data-feather="edit-2" style="width:16px;height:16px;"></span> <strong>Edit</strong> - Modify subject
            name, code, description, or status</li>
        <li><span data-feather="trash-2" style="width:16px;height:16px;"></span> <strong>Delete</strong> - Permanently
            remove subject (requires confirmation)</li>
        <li>Subjects are <strong>form-agnostic</strong> - they can be assigned to any class</li>
    </ul>
</div>
<script>
    if (typeof feather !== 'undefined') feather.replace();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/subjects/index.blade.php ENDPATH**/ ?>