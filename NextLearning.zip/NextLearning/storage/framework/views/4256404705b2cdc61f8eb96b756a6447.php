<?php if(session('message')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/includes/flash.blade.php ENDPATH**/ ?>