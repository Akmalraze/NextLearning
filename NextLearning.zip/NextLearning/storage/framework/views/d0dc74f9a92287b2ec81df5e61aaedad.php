<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Class Management</h5>
        <a href="<?php echo e(route('admin.classes.create')); ?>" class="btn btn-primary btn-sm">
            <span data-feather="plus"></span> Add Class
        </a>
    </div>
    <div class="card-body">
        <!-- Search & Filter Form -->
        <form method="GET" action="<?php echo e(route('admin.classes.index')); ?>" class="mb-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search by class name..."
                        value="<?php echo e($search ?? ''); ?>">
                </div>
                <div class="col-md-3">
                    <select name="form_level" class="form-select">
                        <option value="">All Form Levels</option>
                        <?php $__currentLoopData = $formLevels ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level); ?>" <?php echo e(($formLevel ?? '' )==$level ? 'selected' : ''); ?>>
                            <?php echo e($level); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="academic_session" class="form-select">
                        <option value="">All Sessions</option>
                        <?php $__currentLoopData = $academicSessions ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($session); ?>" <?php echo e(($academicSession ?? '' )==$session ? 'selected' : ''); ?>>
                            <?php echo e($session); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">
                        <span data-feather="search"></span> Filter
                    </button>
                </div>
            </div>
        </form>

        <!-- Classes Table -->
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Form Level</th>
                        <th>Class Name</th>
                        <th>Academic Session</th>
                        <th>Homeroom Teacher</th>
                        <th>Students</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($class->form_level); ?></td>
                        <td><?php echo e($class->name); ?></td>
                        <td><?php echo e($class->academic_session); ?></td>
                        <td>
                            <?php if($class->homeroomTeacher): ?>
                            <?php echo e($class->homeroomTeacher->name); ?>

                            <?php else: ?>
                            <span class="text-muted">Not assigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo e($class->activeStudents()->count()); ?> students</span>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.classes.show', $class->id)); ?>"
                                    class="btn btn-sm btn-outline-info" title="View">
                                    <span data-feather="file-text"></span>
                                </a>
                                <a href="<?php echo e(route('admin.classes.enrollments', $class->id)); ?>"
                                    class="btn btn-sm btn-outline-primary" title="Manage Enrollments">
                                    <span data-feather="users"></span>
                                </a>
                                <a href="<?php echo e(route('admin.classes.edit', $class->id)); ?>"
                                    class="btn btn-sm btn-outline-warning" title="Edit">
                                    <span data-feather="edit-2"></span>
                                </a>
                                <form action="<?php echo e(route('admin.classes.destroy', $class->id)); ?>" method="POST"
                                    style="display:inline;" onsubmit="return confirm('Delete this class?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                        <span data-feather="trash-2"></span>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No classes found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-3 d-flex justify-content-center">
            <?php echo e($classes->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>

<!-- Quick Tips -->
<div class="alert alert-info mt-4">
    <strong><span data-feather="info"></span> Quick Tips - Action Icons:</strong>
    <ul class="mb-0 mt-2">
        <li><span data-feather="file-text" style="width:16px;height:16px;"></span> <strong>Manage Assignments</strong> -
            Assign teachers and
            subjects to classes</li>
        <li><span data-feather="users" style="width:16px;height:16px;"></span> <strong>Manage Enrollments</strong> - Add
            or remove students from this class</li>
        <li><span data-feather="edit-2" style="width:16px;height:16px;"></span> <strong>Edit</strong> - Modify class
            name, form level, session, or homeroom teacher</li>
        <li><span data-feather="trash-2" style="width:16px;height:16px;"></span> <strong>Delete</strong> - Permanently
            remove class (requires confirmation)</li>
    </ul>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/classes/index.blade.php ENDPATH**/ ?>