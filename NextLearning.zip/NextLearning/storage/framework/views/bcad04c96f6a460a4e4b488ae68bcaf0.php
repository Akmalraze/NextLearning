<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Assessment Management</h5>
    </div>
    <div class="card-body">
        <?php if(auth()->user()->hasRole('Teacher')): ?>
            <?php if(isset($classSubjectCombos) && $classSubjectCombos->isNotEmpty()): ?>
                <!-- Class-Subject Cards -->
                <?php if(!$classId || !$subjectId): ?>
                <div class="row mb-4">
                    <h6 class="mb-3">Select Class & Subject:</h6>
                    <?php $__currentLoopData = $classSubjectCombos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 shadow-sm border-0" style="cursor: pointer; transition: transform 0.2s;" 
                             onclick="window.location.href='<?php echo e(route('assessments.index', ['class_id' => $combo['class_id'], 'subject_id' => $combo['subject_id']])); ?>'"
                             onmouseover="this.style.transform='scale(1.02)'" 
                             onmouseout="this.style.transform='scale(1)'">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <span data-feather="book-open" style="width: 20px; height: 20px;"></span>
                                    <?php echo e($combo['class'] ? $combo['class']->form_level . ' ' . $combo['class']->name : 'N/A'); ?>

                                </h5>
                                <p class="card-text mb-2">
                                    <span data-feather="book" style="width: 16px; height: 16px;"></span>
                                    <strong><?php echo e($combo['subject'] ? $combo['subject']->name : 'N/A'); ?></strong>
                                </p>
                                <?php if($combo['subject'] && $combo['subject']->code): ?>
                                <small class="text-muted">Code: <?php echo e($combo['subject']->code); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- Selected Class-Subject View -->
                <?php if($classId && $subjectId && $selectedClass && $selectedSubject): ?>
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h5>
                                <span data-feather="book-open"></span>
                                <?php echo e($selectedClass->form_level); ?> <?php echo e($selectedClass->name); ?> - 
                                <span data-feather="book"></span>
                                <?php echo e($selectedSubject->name); ?>

                            </h5>
                            <a href="<?php echo e(route('assessments.index')); ?>" class="btn btn-sm btn-outline-secondary mt-2">
                                <span data-feather="arrow-left"></span> Back to All Classes
                            </a>
                        </div>
                        <a href="<?php echo e(route('assessments.create', ['class_id' => $classId, 'subject_id' => $subjectId])); ?>" 
                           class="btn btn-primary">
                            <span data-feather="plus"></span> Create Assessment
                        </a>
                    </div>

                    <!-- Search & Filter -->
                    <form method="GET" class="mb-4">
                        <input type="hidden" name="class_id" value="<?php echo e($classId); ?>">
                        <input type="hidden" name="subject_id" value="<?php echo e($subjectId); ?>">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <input type="text" name="search" class="form-control" placeholder="Search by title..."
                                    value="<?php echo e($search ?? ''); ?>">
                            </div>
                            <div class="col-md-3">
                                <select name="type" class="form-select">
                                    <option value="">All Types</option>
                                    <option value="quiz" <?php echo e(($type ?? '') === 'quiz' ? 'selected' : ''); ?>>Quiz</option>
                                    <option value="test" <?php echo e(($type ?? '') === 'test' ? 'selected' : ''); ?>>Test</option>
                                    <option value="homework" <?php echo e(($type ?? '') === 'homework' ? 'selected' : ''); ?>>Homework</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-secondary w-100">
                                    <span data-feather="search"></span> Filter
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Assessments List -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>End Date & Time</th>
                                    <th>Total Marks</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($assessment->title); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($assessment->type === 'quiz' ? 'info' : ($assessment->type === 'test' ? 'warning' : 'success')); ?>">
                                            <?php echo e(ucfirst($assessment->type)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($assessment->end_date ? $assessment->end_date->format('M d, Y h:i A') : 'N/A'); ?></td>
                                    <td><?php echo e(number_format($assessment->total_marks, 2)); ?></td>
                                    <td>
                                        <?php if($assessment->is_published): ?>
                                        <span class="badge bg-success">Published</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('assessments.show', $assessment->id)); ?>"
                                                class="btn btn-sm btn-outline-info" title="View Details">
                                                <span data-feather="eye"></span> Details
                                            </a>
                                            <a href="<?php echo e(route('assessments.edit', $assessment->id)); ?>"
                                                class="btn btn-sm btn-outline-warning" title="Edit">
                                                <span data-feather="edit-2"></span> Edit
                                            </a>
                                            <form action="<?php echo e(route('assessments.destroy', $assessment->id)); ?>" method="POST"
                                                style="display:inline;" onsubmit="return confirm('Delete this assessment?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <span data-feather="trash-2"></span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted">
                                        No assessments found for this class and subject.
                                        <br>
                                        <a href="<?php echo e(route('assessments.create', ['class_id' => $classId, 'subject_id' => $subjectId])); ?>" 
                                           class="btn btn-sm btn-primary mt-2">
                                            <span data-feather="plus"></span> Create First Assessment
                                        </a>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if(isset($assessments) && method_exists($assessments, 'links')): ?>
                    <div class="mt-4">
                        <?php echo e($assessments->links()); ?>

                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-warning">
                    <span data-feather="alert-triangle"></span>
                    You are not assigned to any classes or subjects. Please contact the administrator to assign you to classes and subjects.
                </div>
            <?php endif; ?>

        <?php elseif(auth()->user()->hasRole('Student')): ?>
            <!-- Student View -->
            <?php if(isset($message)): ?>
            <div class="alert alert-warning">
                <span data-feather="alert-triangle"></span>
                <?php echo e($message); ?>

            </div>
            <?php else: ?>
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5>Published Assessments</h5>
                    <div>
                        <span class="badge bg-danger me-2">
                            <span data-feather="alert-circle" style="width: 12px; height: 12px;"></span> Not Attempted
                        </span>
                        <span class="badge bg-warning me-2">In Progress</span>
                        <span class="badge bg-success">Submitted</span>
                    </div>
                </div>
                
                <!-- Search & Filter -->
                <form method="GET" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <input type="text" name="search" class="form-control" placeholder="Search by title..."
                                value="<?php echo e($search ?? ''); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="type" class="form-select">
                                <option value="">All Types</option>
                                <option value="quiz" <?php echo e(($type ?? '') === 'quiz' ? 'selected' : ''); ?>>Quiz</option>
                                <option value="test" <?php echo e(($type ?? '') === 'test' ? 'selected' : ''); ?>>Test</option>
                                <option value="homework" <?php echo e(($type ?? '') === 'homework' ? 'selected' : ''); ?>>Homework</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-secondary w-100">
                                <span data-feather="search"></span> Filter
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Active Assessments (Still Can Answer) - Priority Order -->
                <?php if(isset($activeAssessments) && $activeAssessments->isNotEmpty()): ?>
                <div class="mb-5">
                    <h6 class="mb-3 text-primary">
                        <span data-feather="clock"></span> Active Assessments (Priority Order - Expires Soonest First)
                    </h6>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Subject</th>
                                    <th>End Date & Time</th>
                                    <th>Status</th>
                                    <th>Total Marks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $activeAssessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $submission = $submissions[$assessment->id] ?? null;
                                $now = now();
                                $hasStarted = $assessment->start_date === null || $now->gte($assessment->start_date);
                                
                                // Determine status (active assessments are not submitted)
                                if ($submission && $submission->started_at && !$submission->submitted_at) {
                                    $status = 'in_progress';
                                    $statusText = 'In Progress';
                                    $statusBadge = 'warning';
                                } elseif (!$hasStarted) {
                                    $status = 'not_started';
                                    $statusText = 'Not Started Yet';
                                    $statusBadge = 'info';
                                } else {
                                    $status = 'not_attempted';
                                    $statusText = 'Not Attempted';
                                    $statusBadge = 'danger';
                                }
                            ?>
                            <tr class="<?php echo e($status === 'not_attempted' ? 'table-danger' : ($status === 'in_progress' ? 'table-warning' : '')); ?>">
                                <td>
                                    <strong><?php echo e($assessment->title); ?></strong>
                                    <?php if($status === 'not_attempted'): ?>
                                    <span class="badge bg-danger ms-2" title="Action Required">
                                        <span data-feather="alert-circle" style="width: 12px; height: 12px;"></span>
                                    </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($assessment->type === 'quiz' ? 'info' : ($assessment->type === 'test' ? 'warning' : 'success')); ?>">
                                        <?php echo e(ucfirst($assessment->type)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($assessment->subject ? $assessment->subject->name : 'N/A'); ?></td>
                                <td>
                                    <?php if($assessment->end_date): ?>
                                        <?php echo e($assessment->end_date->format('M d, Y h:i A')); ?>

                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($statusBadge); ?>"><?php echo e($statusText); ?></span>
                                </td>
                                <td><?php echo e(number_format($assessment->total_marks, 2)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('assessments.show', $assessment->id)); ?>"
                                        class="btn btn-sm btn-<?php echo e($status === 'not_attempted' ? 'danger' : ($status === 'in_progress' ? 'warning' : 'outline-info')); ?>" 
                                        title="View">
                                        <span data-feather="<?php echo e($status === 'not_attempted' ? 'arrow-right-circle' : 'eye'); ?>"></span> 
                                        <?php echo e($status === 'not_attempted' ? 'Start' : 'View'); ?>

                                    </a>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php elseif(isset($activeAssessments) && $activeAssessments->isEmpty() && (!isset($submittedAssessments) || $submittedAssessments->isEmpty()) && (!isset($expiredAssessments) || $expiredAssessments->isEmpty())): ?>
                <div class="alert alert-info">
                    <span data-feather="info"></span>
                    No published assessments available.
                </div>
                <?php endif; ?>

                <!-- Submitted Assessments (Separate Table) -->
                <?php if(isset($submittedAssessments) && $submittedAssessments->isNotEmpty()): ?>
                <div class="mb-5">
                    <h6 class="mb-3 text-success">
                        <span data-feather="check-circle"></span> Submitted Assessments
                    </h6>
                    <div class="table-responsive">
                        <table class="table table-hover table-success">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Subject</th>
                                    <th>Submitted Date & Time</th>
                                    <th>Status</th>
                                    <th>Score</th>
                                    <th>Total Marks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $submittedAssessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $submission = $submissions[$assessment->id] ?? null;
                                    $status = 'submitted';
                                    $statusText = 'Submitted';
                                    $statusBadge = 'success';
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($assessment->title); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($assessment->type === 'quiz' ? 'info' : ($assessment->type === 'test' ? 'warning' : 'success')); ?>">
                                            <?php echo e(ucfirst($assessment->type)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($assessment->subject ? $assessment->subject->name : 'N/A'); ?></td>
                                    <td>
                                        <?php if($submission && $submission->submitted_at): ?>
                                            <?php echo e($submission->submitted_at->format('M d, Y h:i A')); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($statusBadge); ?>"><?php echo e($statusText); ?></span>
                                    </td>
                                    <td>
                                        <?php if($submission && $submission->score !== null && $assessment->show_marks): ?>
                                            <strong><?php echo e(number_format($submission->score, 2)); ?></strong>
                                            <br><small class="text-muted">(<?php echo e(number_format(($submission->score / $assessment->total_marks) * 100, 2)); ?>%)</small>
                                        <?php elseif($submission && $submission->score === null): ?>
                                            <span class="text-muted">Pending</span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($assessment->total_marks, 2)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('assessments.show', $assessment->id)); ?>"
                                            class="btn btn-sm btn-outline-success" 
                                            title="View Submission">
                                            <span data-feather="eye"></span> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Expired Assessments (Separate Table) -->
                <?php if(isset($expiredAssessments) && $expiredAssessments->isNotEmpty()): ?>
                <div class="mb-4">
                    <h6 class="mb-3 text-muted">
                        <span data-feather="x-circle"></span> Expired Assessments (View Only)
                    </h6>
                    <div class="table-responsive">
                        <table class="table table-hover table-secondary">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Subject</th>
                                    <th>End Date & Time</th>
                                    <th>Status</th>
                                    <th>Total Marks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $expiredAssessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $submission = $submissions[$assessment->id] ?? null;
                                    $now = now();
                                    
                                    // Determine status for expired
                                    if ($submission && $submission->submitted_at) {
                                        $status = 'submitted';
                                        $statusText = 'Submitted';
                                        $statusBadge = 'success';
                                    } else {
                                        $status = 'expired';
                                        $statusText = 'Expired - Not Submitted';
                                        $statusBadge = 'secondary';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($assessment->title); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($assessment->type === 'quiz' ? 'info' : ($assessment->type === 'test' ? 'warning' : 'success')); ?>">
                                            <?php echo e(ucfirst($assessment->type)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($assessment->subject ? $assessment->subject->name : 'N/A'); ?></td>
                                    <td>
                                        <?php if($assessment->end_date): ?>
                                            <?php echo e($assessment->end_date->format('M d, Y h:i A')); ?>

                                            <br><small class="text-danger">(Expired)</small>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($statusBadge); ?>"><?php echo e($statusText); ?></span>
                                        <?php if($submission && $submission->score !== null && $status === 'submitted' && $assessment->show_marks): ?>
                                        <br><small class="text-muted">Score: <?php echo e(number_format($submission->score, 2)); ?>/<?php echo e(number_format($assessment->total_marks, 2)); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($assessment->total_marks, 2)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('assessments.show', $assessment->id)); ?>"
                                            class="btn btn-sm btn-outline-secondary" 
                                            title="View (Read Only)">
                                            <span data-feather="eye"></span> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-danger">
                <span data-feather="alert-circle"></span>
                Access denied. Only teachers and students can view assessments.
            </div>
        <?php endif; ?>
    </div>
</div>
<script>
    if (typeof feather !== 'undefined') feather.replace();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageAssessment/index.blade.php ENDPATH**/ ?>