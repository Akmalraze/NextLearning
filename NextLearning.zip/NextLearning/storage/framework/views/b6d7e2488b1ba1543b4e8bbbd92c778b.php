<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Class Details: <?php echo e($class->form_level); ?> <?php echo e($class->name ?? $class->class_name); ?></h5>
        <div>
            <a href="<?php echo e(route('admin.classes.enrollments', $class->id)); ?>" class="btn btn-primary btn-sm me-2">
                <span data-feather="users"></span> Manage Students
            </a>
            <a href="<?php echo e(route('admin.classes.edit', $class->id)); ?>" class="btn btn-warning btn-sm me-2">
                <span data-feather="edit-2"></span> Edit
            </a>
            <a href="<?php echo e(route('admin.classes.index')); ?>" class="btn btn-secondary btn-sm">
                <span data-feather="arrow-left"></span> Back
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-0">
            <div class="col-md-6">
                <p><strong>Form Level:</strong> <span class="badge bg-primary"><?php echo e($class->form_level); ?></span></p>
                <p><strong>Academic Session:</strong> <?php echo e($class->academic_session); ?></p>
                <p><strong>Homeroom Teacher:</strong>
                    <?php if($class->homeroomTeacher): ?>
                    <?php echo e($class->homeroomTeacher->name); ?>

                    <?php else: ?>
                    <span class="text-muted">Not assigned</span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="col-md-6">
                <p><strong>Total Students:</strong> <?php echo e($students->total()); ?></p>
                <p><strong>Subjects Assigned:</strong> <?php echo e($subjects->count()); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Subject-Teacher Assignments -->
<div class="card">
    <div class="card-header bg-primary text-white">
        <h6 class="mb-0"><span data-feather="book-open"></span> Subject-Teacher Assignments</h6>
    </div>
    <div class="card-body">
        <!-- Assign Teacher Form -->
        <div class="card mb-4">
            <div class="card-header bg-body-secondary">
                <strong><span data-feather="user-plus"></span> Assign Teacher to Subject</strong>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.classes.assign-teacher', $class->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-5">
                            <label for="subject_id" class="form-label">Subject*</label>
                            <select name="subject_id" id="subject_id" class="form-select" required>
                                <option value="">Select Subject...</option>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->id); ?>">
                                    <?php echo e($subject->name); ?> (<?php echo e($subject->code); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label for="teacher_id" class="form-label">Teacher*</label>
                            <select name="teacher_id" id="teacher_id" class="form-select" required>
                                <option value="">Select Teacher...</option>
                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($teacher->id); ?>">
                                    <?php echo e($teacher->name); ?>

                                    <?php if($teacher->id_number): ?>
                                    (ID: <?php echo e($teacher->id_number); ?>)
                                    <?php endif; ?>
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-success w-100">
                                <span data-feather="plus-circle"></span> Assign
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Current Assignments -->
        <?php if($assignments->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Subject Code</th>
                        <th>Subject Name</th>
                        <th>Assigned Teacher</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="badge bg-info"><?php echo e($assignment->subject->code); ?></span>
                        </td>
                        <td>
                            <strong><?php echo e($assignment->subject->name); ?></strong>
                        </td>
                        <td>
                            <span data-feather="user"></span>
                            <?php echo e($assignment->teacher->name); ?>

                            <?php if($assignment->teacher->id_number): ?>
                            <small class="text-muted">(ID: <?php echo e($assignment->teacher->id_number); ?>)</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form action="<?php echo e(route('admin.classes.unassign-teacher', $assignment->id)); ?>" method="POST"
                                onsubmit="return confirm('Remove <?php echo e($assignment->teacher->name); ?> from teaching <?php echo e($assignment->subject->name); ?>?');"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Remove assignment">
                                    <span data-feather="x-circle"></span>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="alert alert-warning">
            <span data-feather="alert-triangle"></span> No subjects assigned to teachers yet in this class.
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
    if (typeof feather !== 'undefined') feather.replace();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/classes/show.blade.php ENDPATH**/ ?>