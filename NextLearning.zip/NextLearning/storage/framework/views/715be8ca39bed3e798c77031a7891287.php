<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">

        <?php if(!empty($subjectId) && $subjects->where('id', $subjectId)->count()): ?>
            <ul class="nav flex-column">

                <?php $__currentLoopData = $subjects->where('id', $subjectId); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">

                        
                        <a class="nav-link fw-bold bg-light text-primary"
                           href="<?php echo e(route('modules-list', $subjectId)); ?>">
                            <span data-feather="book-open"></span>
                            <?php echo e($subject->name); ?>

                        </a>

                        <?php if(!auth()->user()->hasRole('Student')): ?> 

                        
                        <div class="px-3 mt-2 mb-2">
                            <a href="<?php echo e(route('modules-list', $subjectId)); ?>"
                               class="btn btn-sm btn-outline-primary w-100">
                                <span data-feather="list"></span>
                                View All Modules
                            </a>
                            
                        </div>
                        
                        <div class="px-3 mt-2 mb-2">
                            <a href="<?php echo e(route('modules-index', ['subject_id' => $subjectId])); ?>" 
                                class="btn btn-sm btn-outline-primary w-100">
                                    <span data-feather="home"></span>
                                    Add New Module
                            </a>

                            
                        </div>

                        <?php endif; ?>

                        
                        <ul class="nav flex-column ms-3 mt-1">
                            <?php $__currentLoopData = $subject->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link
                                        <?php echo e($module->id == $currentModuleId
                                            ? 'fw-bold text-primary bg-light rounded'
                                            : ''); ?>"
                                       href="<?php echo e(route('modules-view', $module->id)); ?>">
                                        <span data-feather="layers"></span>
                                        <?php echo e($module->modules_name); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        <?php else: ?>
            <p class="text-muted px-3">
                Please select a subject to view its modules.
            </p>
        <?php endif; ?>

    </div>
</nav>
<?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/admin/includes/subject.blade.php ENDPATH**/ ?>