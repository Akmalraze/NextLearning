<?php $__env->startSection('content'); ?>

<div class="row">
   
    
    <div class="col-md-9 col-lg-10">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Module Management</span>

                
                <form method="GET" action="<?php echo e(route('modules-index')); ?>" class="form-inline">
                    <select name="subject_id" class="form-control form-control-sm mr-2" onchange="this.form.submit()">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subject->id); ?>" <?php echo e($subjectId == $subject->id ? 'selected' : ''); ?>>
                                <?php echo e($subject->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>

            <div class="card-body">
                <?php if($modules->count() > 0): ?>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Module Name</th>
                                <th>Description</th>
                                <th>Subject</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($index + 1); ?></th>
                                    <td><?php echo e($module->modules_name); ?></td>
                                    <td><?php echo e(Str::limit($module->modules_description, 60)); ?></td>
                                    <td><?php echo e($module->subject->name ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('modules-view', $module->id)); ?>" class="btn btn-sm btn-info">View</a>
                                        <?php if(!auth()->user()->hasRole('Student')): ?> 
                                            <a href="<?php echo e(route('modules-edit', $module->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('modules-destroy', $module->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    
                    <div class="d-flex justify-content-end">
                        <?php echo e($modules->withQueryString()->links()); ?>

                    </div>
                <?php else: ?>
                    <p class="text-center text-muted">No modules found for this subject.</p>
                <?php endif; ?>

                <?php if($subjectId): ?>
                    <?php if(!auth()->user()->hasRole('Student')): ?> 
                        <a class="btn btn-primary" href="<?php echo e(route('modules-create', $subjectId)); ?>">Add New Module</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    });
</script>

<style>
    .sidebar {
        height: 100%;
        min-height: calc(100vh - 56px);
        padding-top: 1rem;
    }
    .bg-purple-300 {
        background-color: #e0c3fc !important;
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\local\htdocs\NextLearning\NextLearning\resources\views/pages/ManageModule/index.blade.php ENDPATH**/ ?>