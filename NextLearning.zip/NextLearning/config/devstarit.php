<?php

return [
    'app_name' => 'NextLearning',
    'app_desc' => 'Learning Management System',
    'author' => 'BrainDev.io',
    'version' => '1.0'
];
